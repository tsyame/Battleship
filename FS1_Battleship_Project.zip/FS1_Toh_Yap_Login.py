# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 23:59:59 2020

@author:
GUI Version:     Amelia Toh Shi Ya
Console Version: Yap Hock Yang, Darren
"""


from datetime import date
import pygame, pygameMenu, time, random, string, sys, os
import tkinter as tk
from tkinter import ttk
sys.path.insert(0, '../../')
import pickle
#------------------------------
#with open('accounts.pkl', 'wb') as handle: #save
    #pickle.dump(account, handle)
#------------------------------


# Center the Game Application
os.environ['SDL_VIDEO_CENTERED'] = '1'

#------------------------------
#Constants and global variables
#------------------------------
PW_REQ= "1. More than 8 characters\n2. Contain at least one UPPER and lower case\n3. Contain at least 1 digit and special symbol\n4. Cannot contain user name"


GAME_INSTR = ['The battleship board is made up of 10 rows and 10 columns',
              'There are 2 depth layers - the Surface and the Subsea',
              'You are given 1 Carrier of length 4 units and 1 Submarine of length 3 units',
              'The Carrier can ONLY be placed on the surface',
              'The Submarine can be placed on either the surface or the subsea',
              'Within the same layer, overlapping of the Carrier and Submarine is NOT allowed']

popupmsg_font = ("franklingothicmediumcond", 13)              

color_white= (255,255,255)
darkblue_color= (8,40,81)
menu_bckgrd_color= (156,156,208)

FPS= 60.0

surface_size=(900,600)
sound= None
surface= None
main_menu= None
image= pygame.image.load('Login Page.png') #to use as background

#------------------------------
#Functions used in main body
#------------------------------
def main_bckgrd():
    """
    menu background

    : return: None
    """
    global surface
    surface.blit(image, (0,0))

def popupmsg(msg, title):
    """
    Creates a pop-up window to show message and title
    When button clicked, pop-up window closes
    """     
    popup = tk.Tk()
    popup.wm_title(title)
    label = ttk.Label(popup, text=msg, font=popupmsg_font)
    label.pack(side="top", fill="x", pady=10)
    B1 = ttk.Button(popup, text="Got it!", command = popup.destroy)
    B1.pack()
    popup.mainloop()

def pw_req():
    """
    Creates a pop-up window to show password requirements
    When button clicked, pop-up window closes
    """    
    popup = tk.Tk()
    popup.wm_title("Password must fulfil")
    label = ttk.Label(popup, text=PW_REQ, font=popupmsg_font)
    label.pack(side="top", fill="x", pady=10)
    B1 = ttk.Button(popup, text="Got it!", command = popup.destroy)
    B1.pack()
    popup.mainloop()

def update_menu_sound(value, enabled):
    """
    Update menu sound.
    """
    global main_menu
    global sound
    if enabled:
        main_menu.set_sound(sound, recursive=True)
        print('Menu sound enabled')
    else:
        main_menu.set_sound(None, recursive=True)
        print('Menu sound disabled')
    
#------------------------
#Main Body
#------------------------
def main(crash=False):
    """
    Main program.
    """
    
    # Globals
    # -------
    global main_menu
    global sound
    global surface

    
    # Initiate pygame
    # ---------------
    pygame.init()

    # For display screen
    # ------------------
    surface= pygame.display.set_mode(surface_size)
    pygame.display.set_caption('Battleships 2.0') #Title of window
    clock= pygame.time.Clock() #to track time within game
    
    # Set sounds
    # ----------
    sound= pygameMenu.sound.Sound()
    sound.load_example_sounds() #load example sounds
    sound.set_sound(pygameMenu.sound.SOUND_TYPE_ERROR, None) #disable a sound

    #------------------------------
    #Logic Check Functions
    #------------------------------
    def data_store():
        """
        Check and store data of the create_acct menu.
        Check if username, password and birthday inputs are logical
        """
        try:
            with open('accounts.pkl', 'rb') as handle: #load
                account = pickle.load(handle)
        except EOFError:
            account={}

        # Convert text inputs to strings
        # ------------------------------
        data = create_acct.get_input_data()
        for k in data.keys():
            if k=='username':
                User= "{0}=>{1}".format(k, data[k])
            elif k=='password':
                Pw="{0}=>{1}".format(k, data[k])
            elif k=='birthday':
                Bday="{0}=>{1}".format(k, data[k])

        # Extract only the data inputs
        # ----------------------------
        user_str= User[10:len(User)+1]
        pw_str= Pw[10:len(Pw)+1]
        bday_str = Bday[10:len(Bday)+1]
        
        #If user did not input data, return error ; else, check validity of data inputs
        if len(user_str)==0:
            popupmsg("No username input detected!", "Error")
        elif len(pw_str)==0:
            popupmsg("No password input detected!", "Error")     
        elif len(bday_str)<8:
            popupmsg("Invalid birthday input detected!", "Error")
        else:
            valid=1
            # Birthday, month and year checks
            # ----------------------------------
            #extract day, month and year input
            d= int(bday_str[:2])
            m= int(bday_str[2:4])
            y= int(bday_str[-4:])

            #check year valid
            currentyear= date.today().year
            while y not in range(currentyear-100,currentyear-9) or len(str(y))!=4:
                popupmsg('You need to be at least 10 years old to play the game', 'Error!')
                valid=0
                create_acct
                break
            
            #check month valid
            while m not in range(1,13):
                popupmsg('Invalid month!', 'Error!')
                valid=0
                create_acct
                break

            #check day valid
            if y%400==0 or y%4 == 0 and y%100 !=0: #is leap year
                if m==2:
                    #is February: 29 days
                    while d not in range(1,30):
                        popupmsg('Invalid date of birth', 'Error!')
                        valid=0
                        create_acct
                        break
                
                elif m in [1,3,5,7,8,10,12]:
                    #not February and has 31 days
                    while d not in range(1,32):
                        popupmsg('Invalid date of birth', 'Error!')
                        valid=0
                        create_acct
                        break
                else:
                    #not February and has 30 days
                    while d not in range(1,31):                        
                        popupmsg('Invalid date of birth', 'Error!')
                        valid=0
                        create_acct
                        break
            else: #not leap year
                if m==2:
                    #is February: 28 days
                    while d not in range(1,29): 
                        popupmsg('Invalid date of birth', 'Error!')
                        valid=0
                        create_acct
                        break                    
                elif m in [1,3,5,7,8,10,12]:
                    while d not in range(1,32):
                        popupmsg('Invalid date of birth', 'Error!')
                        valid=0
                        create_acct
                        break
                else:
                    while d not in range(1,31):
                        popupmsg('Invalid date of birth', 'Error!')
                        valid=0
                        create_acct
                        break


            # Username and Password checks
            # ------------------------------
            #find the shorter length
            u_leng= len(user_str)
            p_leng= len(pw_str)
            if u_leng>=p_leng:
                min_len= p_leng
            else:
                min_len= u_leng
                
            #convert to lowercase
            ustr_low=user_str.lower()
            pstr_low=pw_str.lower()
            
            #define lists
            testu_list=[]
            testp_list=[]
            dupli_list=[]
            
            #find duplicates in username and password inputs
            for a in range(min_len+1-int(min_len/2)):
                testu_list.append(ustr_low[a:a+round(min_len/2)])
                testp_list.append(pstr_low[a:a+round(min_len/2)])
            for i in testu_list:
                for j in testp_list:
                    if i==j:
                        dupli_list.append(i)
                        
            if len(dupli_list)>=2:
                popupmsg("Username is in password!", "Error!")
                valid=0
                create_acct #prompt user again for input
                
            if user_str in account:
                popupmsg('Username already exist!', 'Error!')
                valid=0
                create_acct
                
            elif len(pw_str)<8:
                popupmsg('Password length too short!\nPlease refer to Password requirements.', 'Error!')
                valid=0
                create_acct
                
            elif any(i.isupper() for i in pw_str)==False or any(i.islower() for i in pw_str)==False:
                popupmsg('Password must contain at least 1 upper and 1 lower case letter!\nPlease refer to Password requirements.', 'Error!')
                valid=0
                create_acct
                
            elif any(i.isdigit() for i in pw_str)==False:
                popupmsg('Password must contain at least one digit!\nPlease refer to Password requirements.', 'Error!')
                valid=0
                create_acct
                
            elif all(i.isalnum() for i in pw_str)==True:
                popupmsg('Password must contain at least one special character!\nPlease refer to Password requirements.', 'Error!')
                valid=0
                create_acct
                
            else: #no error
                if valid==1:
                    counter=0
                    popupmsg("Profile stored!\nEnter <backspace> to return to main menu", "WELCOME!")
                    account[user_str]=[pw_str,bday_str,counter]
                    with open('accounts.pkl', 'wb') as handle: #saving
                        pickle.dump(account, handle)

        
    def login_check():
        """
        Check if account exists
        If true, check if password entered is correct
        """        
        try:       
            with open('accounts.pkl', 'rb') as handle: #load
                account = pickle.load(handle)
        except EOFError:
            account={}
            
        # Convert text inputs to strings
        # ------------------------------
        data = login_acct.get_input_data()
        for l in data.keys():
            if l=='user_log':
                User= "{0}=>{1}".format(l, data[l])
            elif l=='pw_log':
                Pw="{0}=>{1}".format(l, data[l])

        # Extract only the data inputs
        # ----------------------------
        user_str= User[10:len(User)+1]
        pw_str= Pw[8:len(Pw)+1]
        
        #If user did not input data, return error ; else, check if username exists
        if len(user_str)==0:
            popupmsg('No username input detected!', 'Error!')
        elif len(pw_str)==0:
            popupmsg('No password input detected!', 'Error!')
            
        else: #input detected, perform checks
            if user_str not in account:
                popupmsg('Username does not exist!', 'Error!')
                
            else: #username exists and password correct
                if account[user_str][0]==pw_str:
                    account[user_str][2]=0        
                    with open('accounts.pkl', 'wb') as handle: #saving
                        pickle.dump(account, handle)
                    pygame.quit() #close window
                    import FS1_Toh_Yap_Game #call game function

                else: #incorrect password, prompt again for input
                    popupmsg('Incorrect password!', 'Error!')
                    if account[user_str][2] <2:
                        account[user_str][2]+=1        
                        with open('accounts.pkl', 'wb') as handle: #saving
                            pickle.dump(account, handle)                        

                    else: #account locked after 3 tries
                        popupmsg('Your account has been locked!\nYou can proceed to unlock with your birthday!', 'Account locked')
                        main_menu.disable()
                        unlock_acct.enable() #call for function to unlock account using birthday
                        

    def unlock_bday():
        """
        Function called when account locked

        To check if birthday input is correct
        If true, unlock account
        """
        try:
            with open('accounts.pkl', 'rb') as handle: #load
                account = pickle.load(handle)
        except EOFError:
            account={}
            
        #Extract data input
        bday_data = unlock_acct.get_input_data()
        
        #Convert text inputs to strings
        for b in bday_data.keys():
            if b=='user_lock':
                user_lock= "{0}=>{1}".format(b, bday_data[b])
            elif b=='bday_lock':
                bday_lock="{0}=>{1}".format(b, bday_data[b])
                
        #Extract only the inputs
        user_str= user_lock[11:len(user_lock)+1]
        bday_str= bday_lock[11:len(bday_lock)+1]
        
        #If user did not input data, return error
        if len(user_str)==0:
            popupmsg('No username input detected!', 'Error!')
            unlock_acct
        elif len(bday_str)!=8:
            popupmsg('Invalid birthday input detected!', 'Error!')
            unlock_acct
            
        else: #input detected, perform checks
            if user_str not in account:
                popupmsg('Username does not exist!', 'Error!')
                unlock_acct
                
            else: #username exists and birthday correct
                if account[user_str][1]==bday_str:
                    popupmsg('Your account has been unlocked\nThe game will start', 'Hooray!')
                    account[user_str][2]=0       
                    with open('accounts.pkl', 'wb') as handle: #saving
                        pickle.dump(account, handle)                     
                    unlock_acct.disable()
                    pygame.quit() #close window
                    import FS1_Toh_Yap_Game #call game function
                    
                else: #incorrect birthday, prompt again for input
                    popupmsg('Birthday does not match username!', 'Error!')
                    unlock_acct           

    
    #------------------------------
    #Menus
    #------------------------------

    # Create Account
    # --------------
    create_acct= pygameMenu.Menu(surface,
                                 bgfun= main_bckgrd,
                                 color_selected= darkblue_color,
                                 font= 'moeumtrexpom',
                                 font_title= pygameMenu.font.FONT_BEBAS,
                                 font_color= color_white,
                                 font_size_title= 20,
                                 font_size= 18,
                                 menu_alpha= 70,
                                 menu_color= menu_bckgrd_color,
                                 menu_color_title= darkblue_color,
                                 rect_width= 2,
                                 menu_height= int(surface_size[1]*0.36),
                                 menu_width= int(surface_size[0]*0.5),
                                 #User press ESC button
                                 onclose= pygameMenu.events.DISABLE_CLOSE,
                                 title= "Create your Profile!",
                                 widget_alignment= pygameMenu.locals.ALIGN_LEFT,
                                 window_height= int(surface_size[1]*0.7),
                                 window_width= int(surface_size[0]*1.49)
                                 )
    
    #button to view password requirements
    create_acct.add_option('See Password Requirements', pw_req, font_size= 14, align=pygameMenu.locals.ALIGN_CENTER) 

    #Add text inputs
    user= create_acct.add_text_input('Username: ',
                                     maxwidth= 30,
                                     textinput_id= 'username',
                                     )
    pw= create_acct.add_text_input('Password: ',
                                   maxwidth= 30,
                                   password= True,
                                   textinput_id= 'password'
                                   )
    
    bday= create_acct.add_text_input('Your birthdate (DDMMYYYY): ',
                                     maxchar= 8,
                                     textinput_id= 'birthday',
                                     input_type= pygameMenu.locals.INPUT_INT,
                                     input_underline= '.',)

    #call function to store accouunt details
    create_acct.add_option('Store Profile details', data_store, align=pygameMenu.locals.ALIGN_CENTER) 

    
    # Account login
    # --------------
    login_acct= pygameMenu.Menu(surface,
                                bgfun= main_bckgrd,
                                color_selected= darkblue_color,
                                font= 'moeumtrexpom',
                                font_title= pygameMenu.font.FONT_BEBAS,
                                font_color= color_white,
                                font_size_title= 20,
                                font_size= 18,
                                menu_alpha= 70,
                                menu_color= menu_bckgrd_color,
                                menu_color_title= darkblue_color,
                                rect_width= 2,
                                menu_height= int(surface_size[1]*0.3),
                                menu_width= int(surface_size[0]*0.5),
                                #User press ESC button
                                onclose= pygameMenu.events.DISABLE_CLOSE,
                                title= "Welcome back!",
                                widget_alignment= pygameMenu.locals.ALIGN_LEFT,
                                window_height= int(surface_size[1]*0.65),
                                window_width= int(surface_size[0]*1.49)
                                )

    
    #Add text inputs
    user_log= login_acct.add_text_input('Username: ',
                                        maxwidth= 30,
                                        textinput_id= 'user_log'
                                        )
    pw_log= login_acct.add_text_input('Password: ',
                                      maxwidth= 30,
                                      password= True,
                                      textinput_id= 'pw_log'
                                      )
    
    #call function to check inputs
    login_acct.add_option('Login', login_check, align=pygameMenu.locals.ALIGN_CENTER) 


    # Unlock using birthday menu
    # --------------------------
    unlock_acct= pygameMenu.Menu(surface,
                                 dopause= False,
                                 color_selected= darkblue_color,
                                 back_box= False,
                                 font= 'moeumtrexpom',
                                 font_title= pygameMenu.font.FONT_BEBAS,
                                 font_color= color_white,
                                 font_size_title= 20,
                                 font_size= 18,
                                 menu_alpha= 70,
                                 menu_color= menu_bckgrd_color,
                                 menu_color_title= darkblue_color,
                                 rect_width= 2,
                                 menu_height= int(surface_size[1]*0.25),
                                 menu_width= int(surface_size[0]*0.5),
                                 #User press ESC button
                                 onclose= pygameMenu.events.EXIT,
                                 title= "Unlock your account now!",
                                 widget_alignment= pygameMenu.locals.ALIGN_LEFT,
                                 window_height= int(surface_size[1]*0.6),
                                 window_width= int(surface_size[0]*1.48)
                                 )

    #Add text inputs
    user_lock= unlock_acct.add_text_input('Username: ',
                                          maxwidth= 30,
                                          textinput_id= 'user_lock') 

    bday_lock= unlock_acct.add_text_input('Birthday: (DDMMYYYY): ',
                                          maxchar= 8,
                                          textinput_id= 'bday_lock',
                                          input_type= pygameMenu.locals.INPUT_INT,
                                          input_underline= '.',)

    #call function to check inputs
    unlock_acct.add_option('Confirm', unlock_bday, align=pygameMenu.locals.ALIGN_CENTER) 

    
    # Instructions
    # -------------
    game_instr= pygameMenu.TextMenu(surface,
                                    bgfun= main_bckgrd,
                                    font= 'moeumtrexpom',
                                    font_title= pygameMenu.font.FONT_BEBAS,
                                    text_color= darkblue_color,
                                    font_color= color_white,
                                    font_size_title= 20,
                                    text_fontsize= 16,
                                    menu_alpha= 85,
                                    menu_color= menu_bckgrd_color,
                                    menu_color_title= darkblue_color,
                                    rect_width= 2,
                                    menu_height= int(surface_size[1]*0.37),
                                    menu_width= int(surface_size[0]*0.71),
                                    #User press ESC button
                                    onclose= pygameMenu.events.DISABLE_CLOSE,
                                    title= "How to Play",
                                    widget_alignment= pygameMenu.locals.ALIGN_LEFT,
                                    window_height= int(surface_size[1]*0.72),
                                    window_width= int(surface_size[0]*1.28)
                                    )

    #add text
    game_instr.add_line(pygameMenu.locals.TEXT_NEWLINE)
    for line in GAME_INSTR:
        game_instr.add_line(line)


    # Main Menu
    # ---------
    main_menu= pygameMenu.Menu(surface,
                               bgfun= main_bckgrd,
                               back_box= False,
                               color_selected= color_white,
                               font= pygameMenu.font.FONT_BEBAS,
                               font_color= darkblue_color,
                               font_size= 18,
                               font_size_title= 20,
                               menu_alpha= 0,
                               menu_color= menu_bckgrd_color,
                               menu_height= int(surface_size[1]*0.3),
                               menu_width= int(surface_size[0]*0.4),
                               rect_width= 2,
                               #User press ESC button
                               onclose= pygameMenu.events.EXIT,
                               title= '',
                               widget_alignment= pygameMenu.locals.ALIGN_RIGHT,
                               window_height= int(surface_size[1]*0.65),
                               window_width= int(surface_size[0]*1.6)
                               )

    main_menu.set_fps(FPS)

    #Add option menus
    main_menu.add_option('New?  Create account here', create_acct)
    main_menu.add_option('Already have an account?  Login here', login_acct)
    main_menu.add_option('Game Instructions', game_instr)
    main_menu.add_selector('Sounds',
                           [('Off', False), ('On', True)],
                           onchange=update_menu_sound)
    main_menu.add_option('Quit', pygameMenu.events.EXIT)
    unlock_acct.disable()

    
    #------------------------------
    #Main loop
    #------------------------------
    while True:
        #Main menu
        events= pygame.event.get()
        main_menu.mainloop(events)
        unlock_acct.mainloop(events)
        
        #Flip surface
        pygame.display.flip()

        #At first loops returns
        if crash:
            break;

if __name__ == '__main__':
    main()
