# -*- coding: utf-8 -*-
"""
Created on Mon Apr 27 23:59:59 2020

@author:
Amelia Toh Shi Ya
"""

from datetime import date
import time, random, string, sys, os, threading
from random import randint, choice
import tkinter as tk
from tkinter import ttk, Frame, Canvas, StringVar, Label

#------------------------------
#Constants
#------------------------------
darkblue_color= '#2a4173'
text_color= '#c3c2e6'

popup_font = ("franklingothicmediumcond", 13) 

#------------------------------
#Functions used in main body
#------------------------------
def errormsg(msg):
    """
    Used to display errors in user input
    
    : return: pop-up box showing the error found
    """      
    popup = tk.Tk()
    popup.wm_title('Error!')
    label = ttk.Label(popup, text=msg, font=popup_font)
    label.pack(side="top", fill="x", pady=10)
    B1 = ttk.Button(popup, text="Got it!", command = popup.destroy)
    B1.pack()
    popup.mainloop()

def forHelpmenu(msg):
    """
    Pops up when "Help" from menubar is clicked
    
    : return: pop-up box showing game instructions
    """     
    popup = tk.Tk()
    popup.wm_title('How to play')
    label = ttk.Label(popup, text=msg, font=popup_font)
    label.pack(side="top", fill="x", pady=10)
    B1 = ttk.Button(popup, text="Got it!", command = popup.destroy)
    B1.pack()
    popup.mainloop()    

def popupmsg(msg, title, buttontext, func):
    """
    Function takes in the message and title to show
    When button clicked, function 'func' is called
    
    : return: function 'func'
    """    
    popup = tk.Tk()
    popup.wm_title(title)
    label = ttk.Label(popup, text=msg, font=popup_font)
    label.pack(side="top", fill="x", pady=10)
    B1 = ttk.Button(popup, text=buttontext, command = lambda: [ f() for f in [popup.destroy, func]])
    B1.pack()
    popup.mainloop()

#------------
#Main body
#------------
class gui(object):
    def __init__(self, master):
        super(gui, self).__init__()

        self.frame= Frame(master)
        self.frame.pack(fill='both', expand='yes')
        
        self.gamescreen= tk.PhotoImage(file='game bckgrd.gif')
        self.w, self.h = self.gamescreen.width(), self.gamescreen.height()

        self.grid_size= 44 #pixels
        self.carr_unit = 4
        self.sub_unit = 3

        # Menubar
        # -------
        menubar= tk.Menu(master)
        master.config(menu=menubar)
        fileMenu= tk.Menu(menubar)
        fileMenu.add_command(label="Exit", command=game_exit, underline = 0)
        menubar.add_cascade(label='File', menu=fileMenu, underline=0)
        helpMenu= tk.Menu(menubar)
        helpMenu.add_command(label='How to play', command = self.showHelp, underline=0)
        menubar.add_cascade(label='Help', menu = helpMenu, underline = 0)

        # Title and game instructions
        # ----------------------------        
        self.canvas= Canvas(self.frame, width=self.w, height=self.h)
        self.screen_size=self.canvas.create_image(0,0, image=self.gamescreen, anchor='nw')
        self.canvas.pack(fill='both', expand='yes')
        title= self.canvas.create_text((self.w/2), 30,
                                       text=" LET THE BATTLE BEGIN! ",
                                       font=['Courier', 25, 'bold'],
                                       fill='white',
                                       justify='center',
                                       tags='start_page')

        shipcells= self.canvas.create_text((self.w/2), 70,
                                           text=" You have 2 ships: the Carrier and the Submarine\nWin by destroying all the computer's ships before yours do!",
                                           font=['Courier', 13, 'bold'],
                                           fill=text_color,
                                           justify='center',
                                           tags='start_page')
        
        # For computer ships placement
        # ----------------------------
        # v=alignment : 1 = vertical ; 2 = horizontal
        # z= depth : 1 = surface ; 2 = subsea
        self.compS_z = choice([1,2])
        self.compS_v = choice([1,2])
        self.compC_z = 1
        self.compC_v = choice([1,2])
        self.row_range = list(range(0,10)) #random x int
        self.col_range = list(range(0,10)) #random y int

        self.comp_Ccoord = [] #carrier coordinates in (x,y,z)
        self.comp_Scoord = [] #submarine coordinates in (x,y,z)
        
        # SPINBOX WIDGET: to get player's ships input
        # -------------------------------------------
        self._v = StringVar() #carrier alignment
        self._x = StringVar() #carrier rows
        self._y = StringVar() #carrier columns
        self._z = StringVar() #carrier depth

        self._subv = StringVar() #submarine alignment
        self._subx = StringVar() #submarine rows
        self._suby = StringVar() #submarine columns
        self._subz = StringVar() #submarine depth

        self.player_Ccoord = [] #carrier coordinates in (x,y,z)
        self.player_Scoord = [] #submarine coordinates in (x,y,z)

        # SPINBOX WIDGET: to get player's target area input
        # -------------------------------------------------
        self._shootx = StringVar() #shoot rows
        self._shooty = StringVar() #shoot columns
        self._shootz = StringVar() #shoot depth

        self.player_shoot_coord = [] #player's shoot coordinates in (x,y,z)
        self.comp_shoot_coord = [] #computer's shoot coordinates in (x,y,z)

        # Takes in coordinates of the ships hit
        # ---------------------------------------
        self.comp_hit = [] #computer's
        self.player_hit = [] #player's

        # Create empty grids & place computer's ships
        # ------------------------------------------------
        self.battle_grids()
        self.comp_ships()

        #Button to start game
        self.start=tk.Button(self.canvas, text="START PLACING SHIPS", command=self.submarine_nav)
        self.start.config(font=('Courier', 13, 'bold'), fg=darkblue_color, bg='white')
        self.start_window=self.canvas.create_window((self.w/2),115,anchor='center', window=self.start, tags='start_page')      

    def showHelp(self):
        """
        Function to show game instructions
        """  
        forHelpmenu("The goal of the game is to sink the other player's ships before they sink yours.\
        \n\
        \nEach player is given 2 ships - the carrier and the submarine.\
        \nA carrier takes up 4 units ; A submarine takes up 3 units.\
        \nEach player is given 2 depths - the sea surface and subsea - to place the ships.\
        \nEach depth has 10 rows and 10 columns, with columns labeled 1 - 10, and rows labeled A - J.\
        \n\
        \nShips can only be placed on the board vertically or horizontally (no diagonals).\
        \nShips cannot 'float off the board' and the whole ship must be in the 10 X 10 grid.\
        \nShips cannot be placed 'on top' of each other.\
        \nThe head of the ship takes in the coordinates of the row and column selected.\
        \nEg. if A,1 is selected and the submarine is to be aligned vertically, the coordinates will be (A,1), (B,1), (C,1).\
        \n\
        \nEach player take turns to shoot their opponent's ships.\
        \nOnce the game starts, ships cannot be moved.")
        
    #------------------------------
    #Placing 10x10 boards
    #------------------------------
    def battle_grids(self):
        """
        Create empty 10x10 grids on the Surface and Subsea
        """
        #------------------ Sea surface -----------------#        
        self.surface=tk.PhotoImage(file='sea surface.gif')
        w1, h1 = self.surface.width(), self.surface.height()
        self.set_xdist, self.set_ydist, self.set_griddist = 7, 20, 5 #set x,y distance of grids from window border, and between the grids
        self.surface_x, self.surface_y= self.set_xdist, self.h - h1 - self.set_ydist #coordinates for background      
        self.surface_gridx, self.surface_gridy = self.surface_x + self.grid_size, self.surface_y + self.grid_size #coordinates for grid
        self.surface_textx, self.surface_texty = self.surface_gridx - (self.grid_size/2) , self.surface_gridy - (self.grid_size/2) #coordinates for row and column text in grid
        
        self.canvas.create_image(self.surface_x, self.surface_y, image=self.surface, anchor='nw')
        for j in range(10):
            for k in range(10):
                po = ord(str(k)) + 17 #using ASCII table to show Letters
                #drawing grid
                self.canvas.create_rectangle(self.surface_gridx+(j*self.grid_size),
                                             self.surface_gridy+(k*self.grid_size),
                                             self.surface_x+(j*self.grid_size),
                                             self.surface_y+(k*self.grid_size))
                #drawing row and column text on grid
                if j == k == 0:
                    self.canvas.create_text(self.surface_textx + (j*self.grid_size),self.surface_texty+(k*self.grid_size),
                                            text = (chr(po), j+1), font = ["Times New Roman", 11, 'bold'], fill='black')
                elif j in range(1,10) and k==0:
                    self.canvas.create_text(self.surface_textx+(j*self.grid_size),self.surface_texty+(k*self.grid_size),
                                            text = j+1, font = ["Times New Roman", 11, 'bold'], fill='black')
                elif k in range(1,10) and j==0:
                    self.canvas.create_text(self.surface_textx+(j*self.grid_size),self.surface_texty+(k*self.grid_size),
                                            text = chr(po), font = ["Times New Roman", 11, 'bold'], fill='black')

        #------------------ Underwater ie Subsea -----------------#
        self.underwater=tk.PhotoImage(file='underwater.gif')                    
        self.underwater_x, self.underwater_y= w1 + self.set_xdist + self.set_griddist, self.h - h1 - self.set_ydist #coordinates for background
        self.underwater_gridx, self.underwater_gridy = self.underwater_x + self.grid_size , self.underwater_y + self.grid_size #coordinates for grid
        self.underwater_textx, self.underwater_texty = self.underwater_gridx - (self.grid_size/2) , self.underwater_gridy - (self.grid_size/2) #coordinates for row and column text in grid

        self.canvas.create_image(self.underwater_x, self.underwater_y, image=self.underwater, anchor='nw')
        for a in range(10):
            for b in range(10):
                po = ord(str(b)) + 17 #using ASCII table to show Letters
                #drawing grid
                self.canvas.create_rectangle(self.underwater_gridx+(a*self.grid_size),
                                             self.underwater_gridy+(b*self.grid_size),
                                             self.underwater_x +(a*self.grid_size),
                                             self.underwater_y+(b*self.grid_size))
                #drawing row and column text on grid                
                if a == b == 0:
                    self.canvas.create_text(self.underwater_textx+(a*self.grid_size),self.underwater_texty+(b*self.grid_size),
                                            text = (chr(po), a+1), font = ["Times New Roman", 11, 'bold'], fill=text_color)
                elif a in range(1,10) and b==0:
                    self.canvas.create_text(self.underwater_textx+(a*self.grid_size),self.underwater_texty+(b*self.grid_size),
                                            text = a+1, font = ["Times New Roman", 11, 'bold'], fill=text_color)
                elif b in range(1,10) and a==0:
                    self.canvas.create_text(self.underwater_textx+(a*self.grid_size),self.underwater_texty+(b*self.grid_size),
                                            text = chr(po), font = ["Times New Roman", 11, 'bold'], fill=text_color)    

    #------------------------------
    #Setting Computer's Ships
    #------------------------------
    def comp_ships(self):
        """
        To call functions to place computer's ships
        """        
        self.comp_carr()
        self.comp_sub()
        self.comp_checkcollide()

    def comp_carr(self):
        """
        Computer's carrier to take on randomly generated coordinates

        : return: coordinates of computer's carrier in (x,y,z) format
        """
        len_xindex= len(self.row_range)-1
        len_yindex= len(self.col_range)-1        
        #------- Vertical -------#
        if self.compC_v == 1:
            x_index, y_index = randint(0,len_xindex-self.carr_unit), randint(0,len_yindex) #to ensure ships are not out of board
            self.compC_x, self.compC_y = self.row_range[x_index], self.col_range[y_index] #random x and y coordinates
            self.compC_xrange= list(range(self.compC_x, self.compC_x + self.carr_unit)) #used later to check for overlap
            self.comp_Ccoord=[(self.compC_x+r, self.compC_y, self.compC_z) for r in range(self.carr_unit)] #get coordinates in (x,y,z) format
        #------ Horizontal ------#            
        elif self.compC_v == 2:
            x_index, y_index = randint(0,len_xindex), randint(0,len_yindex-self.carr_unit)
            self.compC_x, self.compC_y = self.row_range[x_index], self.col_range[y_index]
            self.compC_yrange= list(range(self.compC_y, self.compC_y + self.carr_unit))
            self.comp_Ccoord=[(self.compC_x , self.compC_y+c, self.compC_z) for c in range(self.carr_unit)]

    def comp_sub(self):
        """
        Computer's submarine to take on randomly generated coordinates

        : return: coordinates of computer's submarine in (x,y,z) format
        """        
        len_xindex= len(self.row_range)-1
        len_yindex= len(self.col_range)-1           
        #------ Vertical ------#
        if self.compS_v == 1 :          
            x_index, y_index = randint(0,len_xindex-self.sub_unit), randint(0,len_yindex) #to ensure ships are not out of board
            self.compS_x, self.compS_y = self.row_range[x_index], self.col_range[y_index] #rand x and y coordinate
            self.compS_xrange= list(range(self.compS_x, self.compS_x + self.sub_unit)) #used later to check for overlap
            self.comp_Scoord=[(self.compS_x+r, self.compS_y, self.compS_z) for r in range(self.sub_unit)] #get coordinates in (x,y,z) format
        #----- Horizontal -----#            
        elif self.compS_v == 2:          
            x_index, y_index = randint(0,len_xindex), randint(0,len_yindex-self.sub_unit)
            self.compS_x, self.compS_y = self.row_range[x_index], self.col_range[y_index]
            self.compS_yrange= list(range(self.compS_y, self.compS_y + self.sub_unit))
            self.comp_Scoord=[(self.compS_x, self.compS_y+c, self.compS_z) for c in range(self.sub_unit)]
                
    def comp_checkcollide(self):
        """
        To check if computer's ships overlapped
        If True, fix computer's carrier and generate new coordinates for the carrier

        : return: new coordinates of computer's carrier in (x,y,z) format
        """
        if self.compS_z == 2: #submarine placed on subsea
            pass
        else:
            for j in self.comp_Scoord:
                if self.compC_v == self.compS_v == 2: #both ships horizontal
                    if self.compC_x==self.compS_x and j[1] in self.compC_yrange:
                        [self.col_range.remove(i[1]) for i in self.comp_Ccoord]
                        self.comp_carr()
                        
                elif self.compC_v == self.compS_v == 1: #both ships vertical
                    if self.compC_y==self.compS_y and j[0] in self.compC_xrange:
                        [self.row_range.remove(i[0]) for i in self.comp_Ccoord]
                        self.comp_carr()
                                
                elif self.compC_v == 1 and self.compS_v == 2: #carrier vertical ; submarine horizontal
                    if self.compS_x in self.compC_xrange and self.compC_y in self.compS_yrange:
                        [self.row_range.remove(i[0]) for i in self.comp_Ccoord]
                        self.comp_carr()
                                    
                elif self.compC_v == 2 and self.compS_v == 1: #carrier horizontal ; submarine vertical
                    if self.compC_x in self.compS_xrange and self.compS_y in self.compC_yrange:
                        [self.col_range.remove(i[1]) for i in self.comp_Ccoord]
                        self.comp_carr()

    #------------------------------
    #Setting Player's Ships
    #------------------------------
    def rotate_image(self, img):
        """
        Function is called when ship alignment is to be vertical
        
        : return: ship that has been rotated 90 degrees
        """
        w, h = img.width(), img.height()
        newimg = tk.PhotoImage(width=h, height=w)
        for x in range(w):
            for y in range(h):
                rgb = '#%02x%02x%02x' % img.get(x, y)
                newimg.put(rgb, (y,w-x))               
        return newimg
        
    def submarine_nav(self):
        """
        Prompt for submarine ship coordinates
        Objects in this function are tagged as 'sub_getinfo'
        """
        self.canvas.delete('start_page') #delete irrelevant objects

        #---------------------------- Title ----------------------------#       
        ship_input=self.canvas.create_text(15, 15,
                                           text="SET UP YOUR SUBMARINE!",
                                           font=['Courier', 15, 'bold'],
                                           fill='white',
                                           anchor='nw',
                                           tags='sub_getinfo')
        self.canvas.create_text(15, 40,
                                text="A submarine is 3 units long",
                                font=['Courier', 11, 'bold'],
                                fill=text_color,
                                anchor='nw',
                                tags='sub_getinfo')        

        self.canvas.create_rectangle(300, 20, 600, 130, fill=darkblue_color, outline=darkblue_color, tags='sub_getinfo')
        
        #-------------------------- Getting Depth, Row, Column and Alignment choices through Spinbox widget --------------------------#
        self.canvas.create_text(350, 40, text="Depth:", font=['Courier', 11, 'bold'], fill='white', tags='sub_getinfo')          
        self.depth= tk.Spinbox(self.canvas, values=('Surface', 'Subsea'), textvariable = self._subz, width = 12, state = "readonly")
        self.depth.config(font=('Courier', 11, 'bold'), fg='white', buttonbackground='#193756', readonlybackground=darkblue_color)
        self.canvas.create_window(470, 40, window=self.depth, tags='sub_getinfo')        
        
        self.canvas.create_text(350, 65, text="Row:", font=['Courier', 11, 'bold'], fill='white', tags='sub_getinfo')
        self.rowchoice=tk.Spinbox(self.canvas, values = ('A','B','C','D','E','F','G','H','I','J'), textvariable = self._subx, width = 12, state = "readonly")
        self.rowchoice.config(font=('Courier', 11, 'bold'), fg='white', buttonbackground='#193756', readonlybackground=darkblue_color)
        self.canvas.create_window(470, 65, window=self.rowchoice, tags='sub_getinfo')

        self.canvas.create_text(350, 90, text="Column:", font=['Courier', 11, 'bold'], fill='white', tags='sub_getinfo')
        self.columnchoice= tk.Spinbox(self.canvas, from_ = 1, to = 10, textvariable = self._suby, width = 12, state = "readonly")
        self.columnchoice.config(font=('Courier', 11, 'bold'), fg='white', buttonbackground='#193756', readonlybackground=darkblue_color)
        self.canvas.create_window(470, 90, window=self.columnchoice, tags='sub_getinfo')

        self.canvas.create_text(350, 115, text="Alignment:", font=['Courier', 11, 'bold'], fill='white', tags='sub_getinfo')
        self.align= tk.Spinbox(self.canvas, values=('Horizontal', 'Vertical'), textvariable = self._subv, width = 12, state = "readonly")
        self.align.config(font=('Courier', 11, 'bold'), fg='white', buttonbackground='#193756', readonlybackground=darkblue_color)
        self.canvas.create_window(470, 115, window=self.align, tags='sub_getinfo')

        # When button clicked, call function 'self.addSub' to draw submarine according to coordinates input #  
        tmp = tk.PhotoImage(file = 'add.gif')
        self.confirm = tk.Button(self.canvas, image = tmp, command = self.addSub, width = 30)
        self.confirm.image = tmp
        self.canvas.create_window(580, 115, window=self.confirm, tags='sub_getinfo')
        
    def carrier_nav(self):
        """
        Prompt player for input of carrier's coordinates
        Objects in this function are tagged as 'carrier_getinfo'
        """
        self.canvas.delete('sub_getinfo') #delete irrelevant objects

        #---------------------------- Title ----------------------------#
        ship_input=self.canvas.create_text(15, 15,
                                           text="SET UP YOUR CARRIER!",
                                           font=['Courier', 15, 'bold'],
                                           fill='white',
                                           anchor='nw',
                                           tags='carrier_getinfo')
        self.canvas.create_text(15, 40,
                                text="A carrier is 4 units long",
                                font=['Courier', 11, 'bold'],
                                fill=text_color,
                                anchor='nw',
                                tags='carrier_getinfo')        

        self.canvas.create_rectangle(300, 20, 600, 130, fill=darkblue_color, outline=darkblue_color, tags='carrier_getinfo')

        #------------------------------------ Setting Depth = Surface for Carrier -----------------------------------#         
        self.canvas.create_text(350, 40, text="Depth:", font=['Courier', 11, 'bold'], fill='white', tags='carrier_getinfo')
        self.canvas.create_text(470, 40, text="Surface", font=['Courier', 11, 'bold'], fill='white', tags='carrier_getinfo')

        #-------------------------- Getting Row, Column and Alignment choices through Spinbox widget --------------------------# 
        self.canvas.create_text(350, 65, text="Row:", font=['Courier', 11, 'bold'], fill='white', tags='carrier_getinfo')
        self.rowchoice=tk.Spinbox(self.canvas, values = ('A','B','C','D','E','F','G','H','I','J'), textvariable = self._x, width = 12, state = "readonly")
        self.rowchoice.config(font=('Courier', 11, 'bold'), fg='white', buttonbackground='#193756', readonlybackground=darkblue_color)
        self.canvas.create_window(470, 65, window=self.rowchoice, tags='carrier_getinfo')

        self.canvas.create_text(350, 90, text="Column:", font=['Courier', 11, 'bold'], fill='white', tags='carrier_getinfo')
        self.columnchoice= tk.Spinbox(self.canvas, from_ = 1, to = 10, textvariable = self._y, width = 12, state = "readonly")
        self.columnchoice.config(font=('Courier', 11, 'bold'), fg='white', buttonbackground='#193756', readonlybackground=darkblue_color)
        self.canvas.create_window(470, 90, window=self.columnchoice, tags='carrier_getinfo')

        self.canvas.create_text(350, 115, text="Alignment:", font=['Courier', 11, 'bold'], fill='white', tags='carrier_getinfo')
        self.align= tk.Spinbox(self.canvas, values=('Horizontal', 'Vertical'), textvariable = self._v, width = 12, state = "readonly")
        self.align.config(font=('Courier', 11, 'bold'), fg='white', buttonbackground='#193756', readonlybackground=darkblue_color)
        self.canvas.create_window(470, 115, window=self.align, tags='carrier_getinfo')

        # When button clicked, call function 'self.addCar' to draw carrier according to coordinates input #        
        tmp = tk.PhotoImage(file = 'add.gif')
        self.confirm = tk.Button(self.canvas, image = tmp, command = self.addCar, width = 30)
        self.confirm.image = tmp
        self.canvas.create_window(580, 115, window=self.confirm, tags='carrier_getinfo')        


    def addSub(self, *args):
        """
        Add submarine on board according to coordinates input
        Submarine placed is tagged as 'sub_placed'
        """        
        try:
            self.canvas.delete('sub_placed') #submarine not shown if coordinates out of board
            # Getting values from SPINBOX #
            self.Svaluex = ord(self._subx.get()) - 65 #row
            self.Svaluey = int(self._suby.get()) #column
            self.Svaluey -= 1 #to avoid off-by-one error
            self.Svaluedepth= self._subz.get() #depth
            self.SvalueAlign = self._subv.get() #alignment

            #submarine image
            self.sub_img= tk.PhotoImage(file='submarine.gif')
            
            if self.Svaluedepth == "Surface":
                self.sub_depth= 1 #let surface=1, subsea=2

                # ------------------------------ coordinates for submarine placement on Surface ------------------------------ #
                # Horizontal #
                sub_x, sub_y = self.surface_gridx + (self.grid_size/2), self.surface_gridy - (self.grid_size/2)
                subalign_row, subalign_col= sub_x + (self.Svaluey*self.grid_size), sub_y + (self.Svaluex*self.grid_size)
                # Vertical #
                sub_vertx, sub_verty = self.surface_gridx - (self.grid_size/2), self.surface_gridy + (self.grid_size/2) 
                subalign_vertrow, subalign_vertcol= sub_vertx + (self.Svaluey*self.grid_size), sub_verty + (self.Svaluex*self.grid_size) 
                
            else: #self.Svaluedepth=="Subsea"
                self.sub_depth= 2

                # ------------------------------ coordinates for submarine placement on Subsea ------------------------------ #                
                # Horizontal #
                sub_x, sub_y = self.underwater_gridx + (self.grid_size/2), self.underwater_gridy - (self.grid_size/2)
                subalign_row, subalign_col= sub_x + (self.Svaluey*self.grid_size), sub_y + (self.Svaluex*self.grid_size)
                # Vertical #
                sub_vertx, sub_verty = self.underwater_gridx - (self.grid_size/2), self.underwater_gridy + (self.grid_size/2)
                subalign_vertrow, subalign_vertcol= sub_vertx + (self.Svaluey*self.grid_size), sub_verty + (self.Svaluex*self.grid_size)

            if self.SvalueAlign == "Horizontal":            
                if self.Svaluey + self.sub_unit > 10: #ship out of board
                    errormsg('You are out of the ocean. Please specify different parameters')
                else: #ship not out of board, check for overlap
                    self.canvas.create_image(subalign_row, subalign_col, image=self.sub_img, tags='sub_placed')
                    self.playerS_yrange = list(range(self.Svaluey, self.Svaluey+self.sub_unit)) # used later for ships overlap check
                    [self.player_Scoord.append((self.Svaluex , self.Svaluey+c, self.sub_depth)) for c in range(self.sub_unit)] #get coordinates in (x,y,z) format

            else: #self.SvalueAlign == "Vertical"
                if self.Svaluex + self.sub_unit > 10:
                    errormsg('You are out of the ocean. Please specify different parameters')
                else:
                    self.sub_rotate=self.rotate_image(self.sub_img) #rotate image
                    self.canvas.create_image(subalign_vertrow, subalign_vertcol, image=self.sub_rotate, tags='sub_placed')
                    self.playerS_xrange = list(range(self.Svaluex, self.Svaluex+self.sub_unit))
                    [self.player_Scoord.append((self.Svaluex+r , self.Svaluey, self.sub_depth)) for r in range(self.sub_unit)] #get coordinates in (x,y,z) format
        except:
            pass
            
        self.carrier_nav() #next, get carrier's input

    def addCar(self, *args):
        """
        Add carrier on board according to coordinates input
        Carrier placed is tagged as 'carr_placed'
        """        
        try:
            self.canvas.delete('carr_placed') #carrier not shown if coordinates out of board
            # Getting values from SPINBOX #
            self.Cvaluex = ord(self._x.get()) - 65 #row
            self.Cvaluey = int(self._y.get()) #column
            self.Cvaluey -= 1 #to avoid off-by-one error
            self.CvalueAlign = self._v.get() #alignment

            #carrier image
            self.carr_img= tk.PhotoImage(file='carrier.gif')
                
            if self.CvalueAlign == "Horizontal":
                if self.Cvaluey + self.carr_unit > 10: #ship out of board
                    errormsg('You are out of the ocean. Please specify different parameters')
                else:
                    #-------------------------------- coordinates for carrier placement --------------------------------#
                    carr_x, carr_y = self.surface_gridx + self.grid_size, self.surface_gridy - (self.grid_size/2)
                    align_row, align_col= carr_x + (self.Cvaluey*self.grid_size), carr_y + (self.Cvaluex*self.grid_size)                
                    self.canvas.create_image(align_row, align_col, image=self.carr_img, tags='carr_placed')
                    self.playerC_yrange = list(range(self.Cvaluey, self.Cvaluey+self.carr_unit)) # used later for ships overlap check
                    [self.player_Ccoord.append((self.Cvaluex , self.Cvaluey+c, 1)) for c in range(self.carr_unit)] #get coordinates in (x,y,z) format ; fix z=1 for carrier

            else: #self.CvalueAlign == "Vertical"
                if self.Cvaluex + self.carr_unit > 10:
                    errormsg('You are out of the ocean. Please specify different parameters')
                else:
                    self.carr_rotate=self.rotate_image(self.carr_img) #rotate image
                    #-------------------------------- coordinates for carrier placement --------------------------------#
                    carr_vertx, carr_verty = self.surface_gridx - (self.grid_size/2), self.surface_gridy + self.grid_size
                    align_vertrow, align_vertcol= carr_vertx + (self.Cvaluey*self.grid_size), carr_verty + (self.Cvaluex*self.grid_size)                
                    self.canvas.create_image(align_vertrow, align_vertcol, image=self.carr_rotate, tags='carr_placed')
                    self.playerC_xrange = list(range(self.Cvaluex, self.Cvaluex+self.carr_unit))
                    [self.player_Ccoord.append((self.Cvaluex+r , self.Cvaluey, 1)) for r in range(self.carr_unit)] #get coordinates in (x,y,z) format
                
        except:
            pass

        self.check_collide('carr_placed', 'sub_placed') #Check whether ships collide        

    def check_collide(self, img1, img2):
        """
        Check for player ships collision
        """
        if self.sub_depth==2: #Submarine in subsea - no overlap
            popupmsg('Your ships have been successfully placed!\nProceed to start battle?', 'Hooray!', 'YES!', self.shoot_input)
        else:
            if self.CvalueAlign== "Horizontal" and self.SvalueAlign== "Vertical": #carrier horizontal ; submarine vertical
                if self.Cvaluex in self.playerS_xrange and self.Svaluey in self.playerC_yrange:
                    errormsg('Ships have overlapped. Please specify different parameters')
                else:
                    popupmsg('Your ships have been successfully placed!\nProceed to start battle?', 'Hooray!', 'YES!', self.shoot_input)
                        
            elif self.CvalueAlign== "Vertical" and self.SvalueAlign== "Horizontal": #carrier vertical ; submarine horizontal
                if self.Cvaluey in self.playerS_yrange and self.Svaluex in self.playerC_xrange:
                    errormsg('Ships have overlapped. Please specify different parameters')
                else:
                    popupmsg('Your ships have been successfully placed!\nProceed to start battle?', 'Hooray!', 'YES!', self.shoot_input)

            else:
                if self.CvalueAlign == self.SvalueAlign == "Horizontal": #both ships horizontal
                    if self.Svaluex==self.Cvaluex: 
                        for i in range(self.sub_unit):
                            if self.playerS_yrange[i] not in self.playerC_yrange:
                                continue
                            else: #ships overlap
                                errormsg('Ships have overlapped. Please specify different parameters')
                        else: #no overlap
                            popupmsg('Your ships have been successfully placed!\nProceed to start battle?', 'Hooray!', 'YES!', self.shoot_input)
                    else: #no overlap
                        popupmsg('Your ships have been successfully placed!\nProceed to start battle?', 'Hooray!', 'YES!', self.shoot_input)                                
                             
                if self.CvalueAlign == self.SvalueAlign == "Vertical": #both ships vertical
                    if self.Svaluey==self.Cvaluey: 
                        for i in range(self.sub_unit):
                            if self.playerS_xrange[i] not in self.playerC_xrange:
                                continue
                            else: #ships overlap
                                errormsg('Ships have overlapped. Please specify different parameters')
                        else: #no overlap
                            popupmsg('Your ships have been successfully placed!\nProceed to start battle?', 'Hooray!', 'YES!', self.shoot_input)
                    else: #no overlap
                        popupmsg('Your ships have been successfully placed!\nProceed to start battle?', 'Hooray!', 'YES!', self.shoot_input)                     

                    
    #------------------------------
    #Setting Player's Shoot Area
    #------------------------------
    def grid_text(self, var):
        """
        Drawing row and column text over shoot area
        Objects placed are tagged as 'shootgrid_text'
        """         
        po = ord(str(var[0])) + 17 #using ASCII table to show Letters
        if var[2] == 1: #if Surface          
            if var[0] == var[1] == 0:
                self.canvas.create_text(self.surface_textx + (var[1]*self.grid_size),self.surface_texty+(var[0]*self.grid_size),
                                        text = (chr(po), var[1]+1), font = ["Times New Roman", 11, 'bold'], fill='black', tags='shootgrid_text')
            elif var[1] in range(1,10) and var[0]==0:
                self.canvas.create_text(self.surface_textx+(var[1]*self.grid_size),self.surface_texty+(var[0]*self.grid_size),
                                        text = var[1]+1, font = ["Times New Roman", 11, 'bold'], fill='black', tags='shootgrid_text')
            elif var[0] in range(1,10) and var[1]==0:
                self.canvas.create_text(self.surface_textx+(var[1]*self.grid_size),self.surface_texty+(var[0]*self.grid_size),
                                        text = chr(po), font = ["Times New Roman", 11, 'bold'], fill='black', tags='shootgrid_text')            
        if var[2] == 2: #if Subsea
            if var[0] == var[1] == 0:
                self.canvas.create_text(self.underwater_textx + (var[1]*self.grid_size),self.underwater_texty+(var[0]*self.grid_size),
                                        text = (chr(po), var[1]+1), font = ["Times New Roman", 11, 'bold'], fill='black', tags='shootgrid_text')
            elif var[1] in range(1,10) and var[0]==0:
                self.canvas.create_text(self.underwater_textx+(var[1]*self.grid_size),self.underwater_texty+(var[0]*self.grid_size),
                                        text = var[1]+1, font = ["Times New Roman", 11, 'bold'], fill='black', tags='shootgrid_text')
            elif var[0] in range(1,10) and var[1]==0:
                self.canvas.create_text(self.underwater_textx+(var[1]*self.grid_size),self.underwater_texty+(var[0]*self.grid_size),
                                        text = chr(po), font = ["Times New Roman", 11, 'bold'], fill='black', tags='shootgrid_text')
                    
    def shoot_input(self):
        """
        Prompt user for coordinates of area of attack
        Objects placed area tagged as 'shoot_area'
        """         
        try:
            self.canvas.delete('compshoot_area', 'shoot_status', 'compshoot_status', 'shootgrid_text') #delete irrelevant objects
            self.shoot_status() #to show player's target area in previous round(s)
        except:
            pass

        # ------------------------------ Text to indicate current player playing ------------------------------ #
        self.canvas.create_rectangle(0, 20, 100, 40, fill=text_color, outline=text_color, tags='shoot_area')
        self.canvas.create_text(20, 20, text="PLAYER", font=['Courier', 16, 'bold'], fill=darkblue_color, tags='shoot_area', anchor='nw')        

        # ------------------------ Title ------------------------ #
        self.canvas.delete('carrier_getinfo', 'carr_placed', 'sub_placed') 
        self.canvas.create_text((self.w/2), self.set_ydist,
                                text=" SELECT YOUR TARGET SPOT ",
                                font=['Courier', 18, 'bold'],
                                fill='white',
                                justify='center',
                                tags='shoot_page')

        self.canvas.create_rectangle(300, 40, 600, 130, fill=darkblue_color, outline=darkblue_color, tags='shoot_page')

        #-------------------------- Prompting for Depth, Row, Column choices through Spinbox widget -------------------------#           
        self.canvas.create_text(350, 60, text="Depth:", font=['Courier', 11, 'bold'], fill='white', tags='shoot_page')          
        self.depth= tk.Spinbox(self.canvas, values=('Surface', 'Subsea'), textvariable = self._shootz, width = 12, state = "readonly")
        self.depth.config(font=('Courier', 11, 'bold'), fg='white', buttonbackground='#193756', readonlybackground=darkblue_color)
        self.canvas.create_window(470, 60, window=self.depth, tags='shoot_page')

        self.canvas.create_text(350, 85, text="Row:", font=['Courier', 11, 'bold'], fill='white', tags='shoot_page')
        self.rowchoice=tk.Spinbox(self.canvas, values = ('A','B','C','D','E','F','G','H','I','J'), textvariable = self._shootx, width = 12, state = "readonly")
        self.rowchoice.config(font=('Courier', 11, 'bold'), fg='white', buttonbackground='#193756', readonlybackground=darkblue_color)
        self.canvas.create_window(470, 85, window=self.rowchoice, tags='shoot_page')

        self.canvas.create_text(350, 110, text="Column:", font=['Courier', 11, 'bold'], fill='white', tags='shoot_page')
        self.columnchoice= tk.Spinbox(self.canvas, from_ = 1, to = 10, textvariable = self._shooty, width = 12, state = "readonly")
        self.columnchoice.config(font=('Courier', 11, 'bold'), fg='white', buttonbackground='#193756', readonlybackground=darkblue_color)
        self.canvas.create_window(470, 110, window=self.columnchoice, tags='shoot_page')

        # When button clicked, call function 'self.get_shoot' to get target area coordinates input # 
        tmp = tk.PhotoImage(file = 'shoot.gif')
        self.confirm = tk.Button(self.canvas, image = tmp, command = self.get_shoot, width = 30)
        self.confirm.image = tmp
        self.confirm.config(bg = darkblue_color)
        self.canvas.create_window(580, 115, window=self.confirm, tags='shoot_page')        

    def get_shoot(self):
        """
        Getting coordinates of player's target area from Spinbox widget
        """         
        self.canvas.delete('shoot_page')
        # ----------- Getting values from SPINBOX ----------- #
        self.player_shootx = ord(self._shootx.get()) - 65 #row
        self.player_shooty = int(self._shooty.get()) #column
        self.player_shooty -= 1 #to avoid off-by-one error
        #let Surface = 1 ; Subsea = 2
        if self._shootz.get() == "Surface":
            self.player_shootz = 1
        elif self._shootz.get() == "Subsea":
            self.player_shootz = 2

        # shoot area = 3x3 grid
        self.player_shootarea = [list(range(self.player_shootx-1, self.player_shootx+2)), list(range(self.player_shooty-1, self.player_shooty+2)), self.player_shootz]

        # ----------- combining ships' coordinates into one list ----------- #
        self.comp_ships_coord = self.comp_Ccoord + self.comp_Scoord #computer
        self.player_ships_coord = self.player_Ccoord + self.player_Scoord #player

        #get coordinates of player's target area in (x,y,z) format
        [self.player_shoot_coord.append((x,y, self.player_shootarea[2])) for x in self.player_shootarea[0] for y in self.player_shootarea[1] if 0<=x<10 and 0<=y<10]

        #function called to determine if opponent's ships were hit
        self.shoot_status() 
        self.shoot_stat_text()
        #function called to determine if player won
        self.player_win()

    def shoot_status(self):
        """
        Function to show in graphics whether player's attempted shot was successful or not
        Objects placed are tagged as 'shoot_area'
        """          
        self.shootsuccess = tk.PhotoImage(file='success.gif')
        self.shootfail = tk.PhotoImage(file='failed.gif')

        self.hit_start_len = len(self.comp_hit) #get initial length of 'self.comp_hit'      
        for i in self.player_shoot_coord:                      
            if i[2] == 1: # if Surface
                shoot_x, shoot_y = self.surface_gridx - (self.grid_size/2), self.surface_gridy - (self.grid_size/2)                                    
            elif i[2] == 2: # if Subsea
                shoot_x, shoot_y = self.underwater_gridx - (self.grid_size/2), self.underwater_gridy - (self.grid_size/2)             

            # initiate attempt shot as failed (3x3 grid)
            align_row, align_col = shoot_x + (i[1]*self.grid_size), shoot_y + (i[0]*self.grid_size)
            self.canvas.create_image(align_row,align_col, image=self.shootfail, tags='shoot_area')           

            # If successful hit, place explosion image and add the coordinates of success shot into 'self.comp_hit' #
            for b in self.comp_ships_coord:
                if b==i: 
                    self.canvas.create_image(align_row,align_col, image=self.shootsuccess, tags='shoot_area')
                    if b not in self.comp_hit:
                        self.comp_hit.append(b)
                    continue

            self.grid_text(i) #draw grid text over shoot area
        self.hit_end_len = len(self.comp_hit) #get the new length of 'self.comp_hit'
        
    def shoot_stat_text(self):
        """
        Objects placed are tagged as 'shoot_status'
        
        : return: texts to inform player of the status of the attempted shots
        """
        # initiate attempt shot as failed (text)
        self.canvas.create_rectangle(100, 60, 800, 90,
                                     fill=darkblue_color,
                                     outline=darkblue_color,
                                     tags='shoot_status')
        self.canvas.create_text(450, 75, text="Oops! You did not hit your opponent's ships",
                                font=['Courier', 18, 'bold'],
                                fill='white',
                                tags='shoot_status')
        
        self.canvas.create_rectangle(300, 100, 600, 120, fill=darkblue_color, outline=darkblue_color, tags='shoot_status')
        self.canvas.create_text(450, 110, text="Your opponent's turn!", font=['Courier', 15, 'bold'], fill='white', tags='shoot_status')

        # text for successful shot
        if self.hit_end_len != self.hit_start_len:
            self.canvas.create_rectangle(100, 60, 800, 90, fill=darkblue_color, outline=darkblue_color, tags='shoot_status')
            self.canvas.create_text(450, 75, text="Congrats! You've hit your opponent's ship!", font=['Courier', 18, 'bold'], fill='white', tags='shoot_status')

            self.canvas.create_rectangle(300, 100, 600, 120, fill=darkblue_color, outline=darkblue_color, tags='shoot_status')
            self.canvas.create_text(450, 110, text="Your opponent's turn!", font=['Courier', 15, 'bold'], fill='white', tags='shoot_status')            

    def player_win(self):
        """
        Checks if the player won the battle
        
        If false, continue with the computer's turn
        If true, announce the winner and exit game
        """        
        if self.hit_end_len == 7: #if all of computer's ships hit
            self.canvas.delete('shoot_status')
            self.canvas.create_rectangle(100, 70, 800, 100, fill='#ededed', outline='#ededed')
            self.canvas.create_text(450, 85, text="Congrats! You've won the battle!", font=['Courier', 18, 'bold'], fill=darkblue_color)

            # Button to exit game #
            self.menu = tk.Button(root, text='Exit', command = game_exit, width = 10)
            self.menu.config(bg = text_color)
            self.canvas.create_window(450, 115, window=self.menu)        
            
        else:
            # 2 seconds delay to show player's target shot #
            call_comp = threading.Timer(2, self.comp_input)
            call_comp.start()
            
    #------------------------------
    #Setting Computer's Shoot Area
    #------------------------------
    def comp_input(self):
        """
        Generate random coordinates for computer's target area
        """          
        self.canvas.delete('shoot_area', 'shootgrid_text', 'shoot_status') #delete irrelevant objects
        
        #-------- Randomised coordinates --------#
        self.comp_shootx = randint(0,9) #row
        self.comp_shooty = randint(0,9) #column
        self.comp_shootz = choice([1,2]) #depth

        #function called to assign values to list
        self.comp_shoot()       

    def comp_shoot(self):
        """
        Assign computer's shoot coordinates into lists
        Objects placed are tagged as 'compshoot_area'
        """          
        # ------------------------------ Text to indicate current player playing ------------------------------ #      
        self.canvas.create_rectangle(780, 20, 900, 40, fill=text_color, outline=text_color, tags='compshoot_area')
        self.canvas.create_text(780, 20, text="COMPUTER", font=['Courier', 16, 'bold'], fill=darkblue_color, tags='compshoot_area', anchor='nw')
        
        # shoot area = 3x3 grid
        self.comp_shootarea = [list(range(self.comp_shootx-1, self.comp_shootx+2)), list(range(self.comp_shooty-1, self.comp_shooty+2)), self.comp_shootz]
        
        # To ensure computer does not shoot the exact same area #
        temp=[(a,b,self.comp_shootz) for a in self.comp_shootarea[0]
              for b in self.comp_shootarea[1] if 0<=a<10 and 0<=b<10]
        dupli=[]
        for val in temp:
            if val in self.comp_shoot_coord:
                dupli.append(val)
                continue
        if len(dupli)==len(temp):
            self.comp_input() #generate random coordinates again

        # get coordinates of computer's target area in (x,y,z) format #
        [self.comp_shoot_coord.append(coord) for coord in temp if coord not in dupli]

        #function called to determine if player's ships were hit
        self.comp_shoot_status()

    def comp_shoot_status(self):
        """
        Function to show in graphics whether computer's attempted shot was successful or not
        Objects placed are tagged as 'compshoot_area'
        """        
        self.compshoot_startlen = len(self.player_hit) #get initial length of 'self.comp_hit'      

        for c in self.comp_shoot_coord:
            if c[2] == 1: # if Surface
                compshoot_x, compshoot_y = self.surface_gridx - (self.grid_size/2), self.surface_gridy - (self.grid_size/2)
            elif c[2] == 2: # if Subsea
                compshoot_x, compshoot_y = self.underwater_gridx - (self.grid_size/2), self.underwater_gridy - (self.grid_size/2)

            # initiate attempt shot as failed (3x3 grid)                
            align_row, align_col = compshoot_x + (c[1]*self.grid_size), compshoot_y + (c[0]*self.grid_size)
            self.canvas.create_image(align_row,align_col, image=self.shootfail, tags='compshoot_area')        

            # If successful hit, place explosion image and add the coordinates of success shot into 'self.comp_hit' #  
            for b in self.player_ships_coord:
                if b==c:                    
                    self.canvas.create_image(align_row,align_col, image=self.shootsuccess, tags='compshoot_area')
                    if b not in self.player_hit:
                        self.player_hit.append(b)                    
                    continue

            self.grid_text(c) #draw grid text over shoot area

        self.compshoot_endlen = len(self.player_hit) #get the new length of 'self.comp_hit'
        self.comp_shoot_text() #call function to display text for status of shot
        self.comp_win() #call function to determine if player lost battle

    def comp_shoot_text(self):
        """
        Objects placed are tagged as 'compshoot_status'
        
        : return: texts to inform player of the status of the computer's attempted shot
        """        
        # initiate attempt shot as failed (text)
        self.canvas.create_rectangle(100, 60, 800, 90, fill=darkblue_color, outline=darkblue_color, tags='compshoot_status')
        self.canvas.create_text(450, 75, text="Your opponent did not hit your ships!", font=['Courier', 18, 'bold'], fill='white', tags='compshoot_status') 

        self.canvas.create_rectangle(300, 100, 600, 120, fill=darkblue_color, outline=darkblue_color, tags='compshoot_status')
        self.canvas.create_text(450, 110, text="Your turn to shoot!", font=['Courier', 15, 'bold'], fill='white', tags='compshoot_status') 

        # text for successful shot
        if self.compshoot_endlen != self.compshoot_startlen:
            self.canvas.create_rectangle(100, 60, 800, 90, fill=darkblue_color, outline=darkblue_color, tags='compshoot_status')
            self.canvas.create_text(450, 75, text="Ohno! Your ship got hit!", font=['Courier', 18, 'bold'], fill='white', tags='compshoot_status')  

    def comp_win(self):
        """
        Checks if the computer won the battle
        
        If false, continue with the player's turn
        If true, announce the winner and exit game
        """
        if self.compshoot_endlen == 7: #if all of player's ships hit
            self.canvas.delete('compshoot_status')
            self.canvas.create_rectangle(100, 60, 800, 90, fill='#ededed', outline='#ededed')
            self.canvas.create_text(450, 75, text="Ohno! You've lost the battle!", font=['Courier', 18, 'bold'], fill=darkblue_color)

            # Button to exit game #
            self.menu = tk.Button(root, text='Exit', command = game_exit, width = 10)
            self.menu.config(bg = text_color)
            self.canvas.create_window(450, 115, window=self.menu)        
            
        else:
            # 2 seconds delay to show computer's target shot #
            call_player = threading.Timer(2, self.shoot_input)
            call_player.start()           


def game_exit():
    """
    Function to exit game
    """     
    root.destroy()
    sys.exit()


root=tk.Tk()
root.title('Battleships 2.0')
root.resizable(0,0)
game=gui(root)
root.protocol("WM_DELETE_WINDOW", game_exit)
root.mainloop()

